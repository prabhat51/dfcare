import React from 'react';
import './App.css';
import DiabeticFootPredictor from './components/DiabeticFootPredictor';

function App() {
  return (
    <div className="App">
      <DiabeticFootPredictor />
    </div>
  );
}

export default App;
